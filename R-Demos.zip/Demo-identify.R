rm(list=ls())

x <- rnorm(1000)
y <- rnorm(1000)

plot(x, y)



